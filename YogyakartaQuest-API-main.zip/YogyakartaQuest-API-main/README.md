# YogyakartaQuest-API
This repository is dedicated to our Yogyakarta Quest application API. Our Cloud Computing team has developed this API to improve the functionality of our application. API data provides comprehensive information about various educational and batik tourism in our application. After the application identifies the batik image, the application immediately provides the user with detailed information about the batik.
<br />

## Our Cloud Computing Team:
Ayunda Wardhatul Fitrah (C296BSX4093)
Cindy Berliana Latansyah (C296BSX3983)
<br />